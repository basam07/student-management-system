
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mbasa
 */
public class DatabaseConnection {
    private static Connection connection=null;
    
    public static Connection getConnection() {
        if (connection==null)
    try
    {
    connection= DriverManager.getConnection("jdbc:mysql://localhost/student_management_system","root","");
    }
    catch (SQLException ex){
        connection=null;
    }
    
    return connection;
    }
}
